package @@project.symbolicName@@.client;

import org.eclipse.scout.commons.exception.ProcessingException;
import org.eclipse.scout.rt.client.AbstractClientSession;
import org.eclipse.scout.rt.client.IClientSession;
import org.eclipse.scout.rt.client.session.ClientSessionProvider;
import org.eclipse.scout.rt.shared.services.common.code.CODES;

import @@project.symbolicName@@.client.desktop.Desktop;

/**
 * <h3>{@link ClientSession}</h3>
 *
 * @author @@user.name@@
 */
public class ClientSession extends AbstractClientSession {

  public ClientSession() {
    super(true);
  }

  /**
   * @return The {@link IClientSession} which is associated with the current thread, or <code>null</code> if not found.
   */
  public static ClientSession get() {
    return ClientSessionProvider.currentSession(ClientSession.class);
  }

  @Override
  protected void execLoadSession() throws ProcessingException {

    //pre-load all known code types
    CODES.getAllCodeTypes("@@project.symbolicName@@.shared");

    setDesktop(new Desktop());
  }

  @Override
  protected void execStoreSession() throws ProcessingException {
  }
}
