package @@project.symbolicName@@.client.settings;

import org.eclipse.scout.commons.annotations.Order;
import @@project.symbolicName@@.shared.Icons;
import org.eclipse.scout.rt.client.ui.desktop.outline.AbstractOutline;
import org.eclipse.scout.rt.shared.TEXTS;

/**
 * <h3>{@link SettingsOutline}</h3>
 *
 * @author @@user.name@@
 */
@Order(3000)
public class SettingsOutline extends AbstractOutline {

  @Override
  protected String getConfiguredTitle() {
    return TEXTS.get("Settings");
  }
  
  @Override
  protected String getConfiguredIconId() {
    return Icons.Gear;
  }
}
