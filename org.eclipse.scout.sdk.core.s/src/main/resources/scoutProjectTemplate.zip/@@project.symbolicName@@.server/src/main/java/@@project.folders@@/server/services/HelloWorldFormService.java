package @@project.symbolicName@@.server.services;

import org.eclipse.scout.commons.exception.ProcessingException;
import org.eclipse.scout.rt.server.Server;

import @@project.symbolicName@@.server.ServerSession;
import @@project.symbolicName@@.shared.dtos.HelloWorldFormData;
import @@project.symbolicName@@.shared.services.IHelloWorldFormService;

/**
 * <h3>{@link HelloWorldFormService}</h3>
 *
 * @author @@user.name@@
 */
@Server
public class HelloWorldFormService implements IHelloWorldFormService {

  @Override
  public HelloWorldFormData load(HelloWorldFormData input) throws ProcessingException {
    StringBuilder msg = new StringBuilder();
    msg.append("Hello ").append(ServerSession.get().getUserId()).append("!");
    input.getMessage().setValue(msg.toString());
    return input;
  }

}
