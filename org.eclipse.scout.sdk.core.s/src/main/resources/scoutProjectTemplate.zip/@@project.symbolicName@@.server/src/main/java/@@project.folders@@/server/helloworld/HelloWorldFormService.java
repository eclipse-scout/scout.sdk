package @@project.symbolicName@@.server.helloworld;

import org.eclipse.scout.commons.exception.ProcessingException;
import org.eclipse.scout.rt.server.Server;

import @@project.symbolicName@@.server.ServerSession;
import @@project.symbolicName@@.shared.helloworld.HelloWorldFormData;
import @@project.symbolicName@@.shared.helloworld.IHelloWorldFormService;

/**
 * <h3>{@link HelloWorldFormService}</h3>
 *
 * @author @@user.name@@
 */
@Server
public class HelloWorldFormService implements IHelloWorldFormService {

  @Override
  public HelloWorldFormData load(HelloWorldFormData input) throws ProcessingException {
    StringBuilder msg = new StringBuilder();
    msg.append("Hello ").append(ServerSession.get().getUserId()).append("!");
    input.getMessage().setValue(msg.toString());
    return input;
  }
}
